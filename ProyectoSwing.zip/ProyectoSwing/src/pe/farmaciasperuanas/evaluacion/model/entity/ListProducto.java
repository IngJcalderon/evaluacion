package pe.farmaciasperuanas.evaluacion.model.entity;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="listProducto")
public class ListProducto {
	
	private List<Producto> listProducto = new ArrayList<Producto>();

	@XmlElement(name = "producto")
	public List<Producto> getListProducto() {
		return listProducto;
	}

	public void setListProducto(List<Producto> listProducto) {
		this.listProducto = listProducto;
	}
	
	
}
