package pe.farmaciasperuanas.evaluacion.model.entity;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.*;

@XmlRootElement(name="producto")
public class Producto implements Serializable{

	private Long id;
	
	private String nombre;
	private Double precio;
	private Date createAt;
	
	@XmlElement
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@XmlElement
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@XmlElement
	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	@XmlElement
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
	
	private static final long serialVersionUID = 1285454306356845809L;

}
