package pe.farmaciasperuanas.evaluacion.client;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.*;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import pe.farmaciasperuanas.evaluacion.model.entity.ListProducto;
import pe.farmaciasperuanas.evaluacion.model.entity.Producto;
import pe.farmaciasperuanas.evaluacion.model.entity.Result;

import com.sun.jersey.api.client.*;
import com.sun.jersey.api.client.config.*;

public class ProductoRestfulClient {
	
	private WebResource webResource;
	private Client client;
	private static final String BASE_URI = "http://localhost:8080";

	public ProductoRestfulClient(){
		client = Client.create(new DefaultClientConfig());
		webResource = client.resource(BASE_URI).path("producto-restservice");
	}
	
	public ListProducto findAll(){
		WebResource resource = webResource;
		return resource.path("listar").accept(MediaType.APPLICATION_JSON).get(ListProducto.class);
	}
	
	public Producto create(Producto producto) throws JsonGenerationException, JsonMappingException, IOException{
		WebResource resource = webResource;
		
		String json = json(producto);
		
		return resource.path("create").accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).post(Producto.class, json);
	}
	
	public Producto update(Producto producto) throws JsonGenerationException, JsonMappingException, IOException{
		WebResource resource = webResource;
		
		String json = json(producto);
		
		return resource.path("update").accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).put(Producto.class, json);
	}
	public Result delete(Long id){
		WebResource resource = webResource;
		return resource.path("delete/"+id).accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).delete(Result.class);
	}
	
	public String json(Producto producto) throws JsonGenerationException, JsonMappingException, IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		String json = objectMapper.writeValueAsString(producto);
		return json;
	}
}
