package pe.farmaciasperuanas.evaluacion;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import pe.farmaciasperuanas.evaluacion.client.ProductoRestfulClient;
import pe.farmaciasperuanas.evaluacion.model.entity.Producto;
import pe.farmaciasperuanas.evaluacion.model.entity.Result;

import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JFrameMain extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JLabel lbId;
	private JTextField textNombre;
	private JTextField textPrecio;
	private static int tipoTransaccion;
	
	private final static int CREATE = 1;
	private final static int UPDATE = 2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameMain frame = new JFrameMain();
					tipoTransaccion = CREATE;
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JFrameMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 475, 334);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 137, 414, 147);
		contentPane.add(scrollPane);
		
		
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Nuevo Producto", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 414, 115);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewId = new JLabel("Id :");
		lblNewId.setBounds(10, 28, 46, 14);
		panel.add(lblNewId);
		
		lbId = new JLabel("");
		lbId.setBounds(92, 28, 46, 14);
		panel.add(lbId);
		
		JLabel lblNewLabel = new JLabel("Nombre :");
		lblNewLabel.setBounds(10, 53, 61, 14);
		panel.add(lblNewLabel);
		
		textNombre = new JTextField();
		textNombre.setBounds(92, 50, 130, 20);
		panel.add(textNombre);
		textNombre.setColumns(10);
		
		JLabel lblPrecio = new JLabel("Precio :");
		lblPrecio.setBounds(232, 53, 46, 14);
		panel.add(lblPrecio);
		
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = lbId.getText();
				String nombre = textNombre.getText();
				String precio = textPrecio.getText();
				
				if (nombre.equals("") ||  precio.equals("")){
					JOptionPane.showMessageDialog(null, "Ingrese los datos");
				}else{
					Producto producto = new Producto();
					producto.setNombre(nombre);
					producto.setPrecio(Double.parseDouble(precio));
					
					try {
						if (tipoTransaccion == CREATE){
							producto = create(producto);
						}else{
							producto.setId(Long.parseLong(id));
							producto = update(producto);
						}	
					} catch (IOException e) {
						//e.printStackTrace();
					}
					 if (producto!= null){
						 JOptionPane.showMessageDialog(null, "Operaci�n Exitosa");
						 LoadData();
					 }	
					
				}
			}
		});
		btnGuardar.setBounds(286, 81, 118, 23);
		panel.add(btnGuardar);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				int selectedRowIndex = table.getSelectedRow();
				
				lbId.setText(dtm.getValueAt(selectedRowIndex, 0).toString());
				textNombre.setText(dtm.getValueAt(selectedRowIndex, 1).toString());
				textPrecio.setText(dtm.getValueAt(selectedRowIndex, 2).toString());
				
				tipoTransaccion = UPDATE;
				btnGuardar.setText("Actualizar");
			}
		});
		scrollPane.setViewportView(table);
		table.setRowSelectionAllowed(true);
		
		textPrecio = new JTextField();
		textPrecio.setBounds(288, 50, 116, 20);
		panel.add(textPrecio);
		textPrecio.setColumns(10);
		
		JButton btnNuevo = new JButton("Nuevo");
		btnNuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tipoTransaccion = CREATE;
				limpiarCampos();
				btnGuardar.setText("Guardar");
			}
		});
		btnNuevo.setBounds(71, 81, 89, 23);
		panel.add(btnNuevo);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = lbId.getText();
				try {
					Result result = delete(Long.parseLong(id));
					if (result.isResult()){
						JOptionPane.showMessageDialog(null, "Operaci�n Exitosa");
						limpiarCampos();
						LoadData();
						tipoTransaccion = CREATE;
					}else{
						JOptionPane.showMessageDialog(null, "Operaci�n No Exitosa");
					}
					
				} catch (NumberFormatException | IOException e) {
					//e.printStackTrace();
				}
			}
		});
		btnEliminar.setBounds(176, 81, 102, 23);
		panel.add(btnEliminar);
		
		 LoadData();
	}
	 private void limpiarCampos(){
		lbId.setText("");
		textNombre.setText("");
		textPrecio.setText("");
	 }
		
	private void LoadData(){
		DefaultTableModel dtm = new DefaultTableModel();
		dtm.addColumn("Id");
		dtm.addColumn("Nombre");
		dtm.addColumn("Precio");
		
		ProductoRestfulClient prc = new ProductoRestfulClient();
		for(Producto producto: prc.findAll().getListProducto()){
			dtm.addRow(new Object[] {producto.getId(), producto.getNombre(), producto.getPrecio()});
		}
		this.table.setModel(dtm);
	}
	
	private Producto create(Producto producto) throws JsonGenerationException, JsonMappingException, IOException{
		ProductoRestfulClient prc = new ProductoRestfulClient();
		return prc.create(producto);
	}
	
	private Producto update(Producto producto) throws JsonGenerationException, JsonMappingException, IOException{
		ProductoRestfulClient prc = new ProductoRestfulClient();
		return prc.update(producto);
	}
	
	private Result delete(Long id) throws JsonGenerationException, JsonMappingException, IOException{
		ProductoRestfulClient prc = new ProductoRestfulClient();
		return prc.delete(id);
	}
}
