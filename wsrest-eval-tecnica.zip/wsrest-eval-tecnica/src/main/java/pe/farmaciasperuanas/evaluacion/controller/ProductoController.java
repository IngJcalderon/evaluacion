package pe.farmaciasperuanas.evaluacion.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import pe.farmaciasperuanas.evaluacion.models.entity.Producto;
import pe.farmaciasperuanas.evaluacion.models.service.IProductoService;



@RestController
@RequestMapping("/producto-restservice")
public class ProductoController {
	
	static final Logger logger = LoggerFactory.getLogger(ProductoController.class);
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	private IProductoService productoService;
	
	
	
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@GetMapping(value = "/listar", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody	
	public JsonNode listar2(){
		ObjectNode node=JsonNodeFactory.instance.objectNode();	
		String json = null;
		ArrayNode  objNodeData = null;
		try {
			json = mapper.writeValueAsString(productoService.findAll());
			objNodeData = (ArrayNode) mapper.readTree(json);
		} catch (IOException e2) {
			logger.error("{}"+e2);
		}
		node.set("producto", objNodeData);
		return node;
	}
	
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@GetMapping("/ver/{id}")
	@ResponseBody	
	public Producto detalle(@PathVariable Long id) {
		Producto producto = productoService.findById(id);
		return producto;
	}
	
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@PostMapping("/create")
	@ResponseBody	
	public Producto save(@RequestBody Producto producto) {
		return productoService.save(producto);
	}
	
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@PutMapping("/update")
	@ResponseBody	
	public Producto update(@RequestBody Producto producto) {
		return productoService.update(producto);
	}
	
	@DeleteMapping("/delete/{id}")
	public JsonNode delete(@PathVariable Long id) {
		ObjectNode node=JsonNodeFactory.instance.objectNode();
		boolean result;
		try {
			productoService.deleteById(id);
			result= true;
		}catch(Exception e) {
			result = false;
		}
		return node.put("result", result);
	}

}
