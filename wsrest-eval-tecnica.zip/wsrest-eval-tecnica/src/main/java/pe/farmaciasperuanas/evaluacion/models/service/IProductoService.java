package pe.farmaciasperuanas.evaluacion.models.service;

import java.util.List;

import pe.farmaciasperuanas.evaluacion.models.entity.Producto;



public interface IProductoService {

	public List<Producto> findAll();
	public Producto findById(Long id);
	public Producto save(Producto producto);
	public Producto update(Producto producto);
	public void deleteById(Long id);
}
