package pe.farmaciasperuanas.evaluacion.models.dao;

import org.springframework.data.repository.CrudRepository;

import pe.farmaciasperuanas.evaluacion.models.entity.Producto;



public interface ProductoDao extends CrudRepository<Producto, Long>{

}
