package pe.farmaciasperuanas.evaluacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsrestEvalTecnicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
